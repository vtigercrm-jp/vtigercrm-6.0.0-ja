<?php
class qCal_Exception_InvalidFile extends qCal_Exception {}