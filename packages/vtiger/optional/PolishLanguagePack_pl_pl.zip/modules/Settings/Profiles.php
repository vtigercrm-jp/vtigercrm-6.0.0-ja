<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
$languageStrings = array(
	// Basic Strings
	'Profiles' => 'Profile',
	'SINGLE_Profiles' => 'Profil',
	'LBL_ADD_RECORD' => 'Dodaj profil',
	
	'LBL_VIEW_PRVILIGE' => 'Przegląd',
	'LBL_EDIT_PRVILIGE' => 'Utwórz / Edytuj',
	'LBL_DELETE_PRVILIGE' => 'Usuń',
	'LBL_FIELD_PRVILIGES' => 'Uprawnienia na polach',
	'LBL_TOOL_PRVILIGES' => 'Narzędzie do uprawnień',
	
);