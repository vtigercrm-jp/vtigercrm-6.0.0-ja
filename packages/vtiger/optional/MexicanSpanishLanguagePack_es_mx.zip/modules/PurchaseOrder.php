<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'SINGLE_PurchaseOrder'         => 'Orden de Compra'             , 
	'LBL_EXPORT_TO_PDF'            => 'Exportar a PDF'              , 
	'LBL_SEND_MAIL_PDF'            => 'Send Email with PDF'         , // TODO: Review
	'LBL_ADD_RECORD'               => 'Agregar Órden de Compra'    , 
	'LBL_RECORDS_LIST'             => 'Lista de Órdenes de Compra' , 
	'LBL_COPY_SHIPPING_ADDRESS'    => 'Copy Shipping Address'       , // TODO: Review
	'LBL_COPY_BILLING_ADDRESS'     => 'Copy Billing Address'        , // TODO: Review
	'LBL_PO_INFORMATION'           => 'Información de la Orden de Compra', 
	'PurchaseOrder No'             => 'No Orden Compra'             , 
	'Requisition No'               => 'Referencia del pedido'       , 
	'Tracking Number'              => 'Nº de seguimiento'          , 
	'Sales Commission'             => 'Comisión sobre Ventas'      , 
	'LBL_PAID'                     => 'Paid'                        , // TODO: Review
	'LBL_BALANCE'                  => 'Balance'                     , // TODO: Review
	'Received Shipment'            => 'Recibido'                    , 
);